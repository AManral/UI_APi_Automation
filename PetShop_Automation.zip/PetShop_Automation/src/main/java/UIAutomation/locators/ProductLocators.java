package UIAutomation.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * TODO Put here a description of what this class does.
 *
 * @author z003x39f.
 *         Created Oct 16, 2020.
 */
public class ProductLocators {

	
	@FindBy(xpath="//a[contains(text(),'Add to cart')]")
	public WebElement AddToCart;

}
