package UIAutomation.Pages;


import org.openqa.selenium.Alert;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

import Base.BaseTest;
import UIAutomation.locators.ProductLocators;

/**
 * TODO Put here a description of what this class does.
 *
 * @author z003x39f.
 *         Created Oct 16, 2020.
 */
public class Product extends BaseTest {

	
	ProductLocators productDescription=null;
	
	Product(){
		this.productDescription=new ProductLocators();
		AjaxElementLocatorFactory factory = new AjaxElementLocatorFactory(driver,10);
		PageFactory.initElements(factory, this.productDescription);
	}
	
	
	 public Product AddToCart(){
			click(productDescription.AddToCart);
			return this;
		  }
	 
	 public TopNav clickOKPopUp() {
		   try {
			Thread.sleep(2000);
		} catch (InterruptedException exception) {
			// TODO Auto-generated catch-block stub.
			exception.printStackTrace();
		}
		 
		   Alert alert= driver.switchTo().alert();
		   System.out.println( alert.getText());
		   alert.accept();
		   return new TopNav(driver);
		  }
}
