package UIAutomation.Pages;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import Base.BaseTest;
import UIAutomation.locators.CartLocator;
import UIAutomation.locators.HomeLocators;

/**
 * TODO Put here a description of what this class does.
 *
 * @author z003x39f.
 *         Created Oct 16, 2020.
 */
public class Cart extends BaseTest {
	
public CartLocator cart;
	
	public Cart() {
		this.cart=new CartLocator();
		AjaxElementLocatorFactory factory = new AjaxElementLocatorFactory(driver,10);
		PageFactory.initElements(factory, this.cart);
	}
	
	public Cart deleteTheProduct_LaptopDelli78gb() {
		//Currently deleting directly otherwise can implement WebTable
		click(cart.Delete_LaptopDelli78gb);
		try {
			Thread.sleep(4000);
		} catch (InterruptedException exception) {
			// TODO Auto-generated catch-block stub.
			exception.printStackTrace();
		}
		return this;	
	}

	public Cart clickOnPlaceOrder() {
		click(cart.PlaceOrder);
		return this;	
	}
	
	public Cart FillPurchaseOrderForm() {
	    try {
			Thread.sleep(2000);
		} catch (InterruptedException exception) {
			// TODO Auto-generated catch-block stub.
			exception.printStackTrace();
		}
		type(cart.PlaceOrderForm_Name, "Alka");
		type(cart.PlaceOrderForm_Country,"India");
		type(cart.PlaceOrderForm_City,"Gurgaon");
		type(cart.PlaceOrderForm_CreditCard,"468478");
		type(cart.PlaceOrderForm_Month,"Oct");
		type(cart.PlaceOrderForm_Year,"2020");
		return this;	
	}
	
	public Cart clickOnPurchase() {
		click(cart.Purchase);
		return this;	
	}
}
