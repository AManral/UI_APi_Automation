package UIAutomation.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import Base.BaseTest;
import UIAutomation.locators.TopNavLocators;



/**
 * TODO Put here a description of what this class does.
 *
 * @author z003x39f.
 *         Created Oct 16, 2020.
 */
public class TopNav {
	
public TopNavLocators topNavigation;
	
	public TopNav(WebDriver driver){
		
		this.topNavigation = new TopNavLocators();
		AjaxElementLocatorFactory factory = new AjaxElementLocatorFactory(driver,10);
		PageFactory.initElements(factory, this.topNavigation);
	}
	
     public Cart gotoCart(){
		BaseTest.click(topNavigation.Cart);
		return new Cart();
		
	}
     
     public Home gotoHome(){
 		BaseTest.click(topNavigation.Home);
 		return new Home();
 		
 	}
	

}
