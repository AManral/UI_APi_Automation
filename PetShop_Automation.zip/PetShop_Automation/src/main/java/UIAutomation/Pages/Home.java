package UIAutomation.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import Base.BaseTest;
import UIAutomation.locators.HomeLocators;

/**
 * TODO Put here a description of what this class does.
 *
 * @author z003x39f.
 *         Created Oct 16, 2020.
 */
public class Home extends BaseTest {

	public HomeLocators home;
	
	
	public Home() {
		this.home=new HomeLocators();
		AjaxElementLocatorFactory factory = new AjaxElementLocatorFactory(driver,10);
		PageFactory.initElements(factory, this.home);
	}
	
	
      public Home gotoPhonesTab(){
		click(home.PhonesTab);
		return this;
	  }
      
      public Home gotoLaptopTab(){
  		click(home.LaptopTab);
  		return this;
  	  }
      
      public Home gotoMonitorTab(){
    		click(home.MonitorTab);
    		return this;
    	  }
      
      public Product selectLaptopSonyVaioi5(){
    	  click(home.SonyVaioi5);
		return new Product();
      }	
	 
      public Product selectLaptopDelli78gb(){
	   click(home.Delli78gb);
	   return new Product();
    	  
    	  
      }


	
}
