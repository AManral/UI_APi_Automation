package com.demoonlineshop.testcases;

import org.testng.annotations.Test;

import Base.BaseTest;
import UIAutomation.Pages.Cart;
import UIAutomation.Pages.Home;
import UIAutomation.Pages.Product;
import UIAutomation.Pages.TopNav;
import UIAutomation.locators.TopNavLocators;


/**
 * TODO Put here a description of what this class does.
 *
 * @author z003x39f. Created Oct 16, 2020.
 */
public class BasicTestCase extends BaseTest {

	
	@Test
	public void EndToEndTest() {

		Home home = new Home();
		Product DescriptionPage= home.gotoLaptopTab().selectLaptopSonyVaioi5();
		TopNav topNavigation=DescriptionPage.AddToCart().clickOKPopUp();
		home= topNavigation.gotoHome();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException exception) {
			// TODO Auto-generated catch-block stub.
			exception.printStackTrace();
		}
		DescriptionPage=home.gotoLaptopTab().selectLaptopDelli78gb();
		topNavigation=DescriptionPage.AddToCart().clickOKPopUp();
		Cart cart=topNavigation.gotoCart();
		cart.deleteTheProduct_LaptopDelli78gb().clickOnPlaceOrder().FillPurchaseOrderForm().clickOnPurchase();
		
	}

}
